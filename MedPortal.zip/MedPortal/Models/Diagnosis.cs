using System.ComponentModel.DataAnnotations;

namespace MedPortal.Models;

public class Diagnosis
{
    public int Id { get; set; }
    [Required, StringLength(120)]
    [Display(Name = "ФИО пациента")]
    public string PatientName { get; set; } = string.Empty;
    [Required, StringLength(160)]
    [Display(Name = "Диагноз")]
    public string Title { get; set; } = string.Empty;
    [StringLength(2000)]
    [Display(Name = "Описание и рекомендации")]
    public string? Description { get; set; }
    [Display(Name = "Дата постановки")]
    [DataType(DataType.Date)]
    public DateTime CreatedAt { get; set; } = DateTime.Today;
    [StringLength(40)]
    [Display(Name = "Статус")]
    public string Status { get; set; } = "Активен";
    public string DoctorId { get; set; } = string.Empty;
    public ApplicationUser? Doctor { get; set; }
}
