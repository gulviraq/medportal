using Microsoft.AspNetCore.Identity;

namespace MedPortal.Models;

public class ApplicationUser : IdentityUser
{
    public string FullName { get; set; } = string.Empty;
    public string Specialty { get; set; } = string.Empty;
    public ICollection<Diagnosis> Diagnoses { get; set; } = new List<Diagnosis>();
}
