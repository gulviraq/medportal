using MedPortal.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
    : IdentityDbContext<ApplicationUser>(options)
{
    public DbSet<Diagnosis> Diagnoses => Set<Diagnosis>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.Entity<Diagnosis>()
            .HasOne(d => d.Doctor)
            .WithMany(u => u.Diagnoses)
            .HasForeignKey(d => d.DoctorId)
            .OnDelete(DeleteBehavior.Cascade);
        builder.Entity<Diagnosis>().HasIndex(d => new { d.DoctorId, d.CreatedAt });
    }
}
