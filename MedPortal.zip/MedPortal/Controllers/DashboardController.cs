using MedPortal.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

[Authorize]
public class DashboardController(ApplicationDbContext db, UserManager<Models.ApplicationUser> userManager) : Controller
{
    public async Task<IActionResult> Index()
    {
        var doctorId = userManager.GetUserId(User)!;
        var diagnoses = db.Diagnoses.Where(d => d.DoctorId == doctorId);
        ViewBag.Total = await diagnoses.CountAsync();
        ViewBag.Active = await diagnoses.CountAsync(d => d.Status == "Активен");
        ViewBag.ThisMonth = await diagnoses.CountAsync(d => d.CreatedAt.Month == DateTime.Today.Month && d.CreatedAt.Year == DateTime.Today.Year);
        ViewBag.Recent = await diagnoses.OrderByDescending(d => d.CreatedAt).Take(5).ToListAsync();
        return View(await userManager.GetUserAsync(User));
    }
}
