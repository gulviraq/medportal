using MedPortal.Data;
using MedPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedPortal.Controllers;

[Authorize]
public class DiagnosesController(ApplicationDbContext db, UserManager<ApplicationUser> userManager) : Controller
{
    private string DoctorId => userManager.GetUserId(User)!;

    public async Task<IActionResult> Index(string? search, string? status, DateTime? from, DateTime? to)
    {
        // Ключевая изоляция: фильтр владельца применяется до пользовательских фильтров.
        var query = db.Diagnoses.AsNoTracking().Where(d => d.DoctorId == DoctorId);
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(d => d.PatientName.Contains(search) || d.Title.Contains(search));
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(d => d.Status == status);
        if (from.HasValue) query = query.Where(d => d.CreatedAt >= from.Value.Date);
        if (to.HasValue) query = query.Where(d => d.CreatedAt < to.Value.Date.AddDays(1));
        ViewBag.Search = search; ViewBag.Status = status;
        ViewBag.From = from?.ToString("yyyy-MM-dd"); ViewBag.To = to?.ToString("yyyy-MM-dd");
        return View(await query.OrderByDescending(d => d.CreatedAt).ToListAsync());
    }

    public IActionResult Create() => View(new Diagnosis { CreatedAt = DateTime.Today });

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Diagnosis model)
    {
        ModelState.Remove(nameof(model.DoctorId)); ModelState.Remove(nameof(model.Doctor));
        if (!ModelState.IsValid) return View(model);
        model.Id = 0; model.DoctorId = DoctorId;
        db.Diagnoses.Add(model); await db.SaveChangesAsync();
        TempData["Success"] = "Диагноз добавлен.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var item = await db.Diagnoses.FirstOrDefaultAsync(d => d.Id == id && d.DoctorId == DoctorId);
        return item == null ? NotFound() : View(item);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Diagnosis model)
    {
        if (id != model.Id) return BadRequest();
        ModelState.Remove(nameof(model.DoctorId)); ModelState.Remove(nameof(model.Doctor));
        if (!ModelState.IsValid) return View(model);
        var item = await db.Diagnoses.FirstOrDefaultAsync(d => d.Id == id && d.DoctorId == DoctorId);
        if (item == null) return NotFound();
        item.PatientName = model.PatientName; item.Title = model.Title;
        item.Description = model.Description; item.CreatedAt = model.CreatedAt; item.Status = model.Status;
        await db.SaveChangesAsync();
        TempData["Success"] = "Изменения сохранены.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await db.Diagnoses.FirstOrDefaultAsync(d => d.Id == id && d.DoctorId == DoctorId);
        if (item == null) return NotFound();
        db.Diagnoses.Remove(item); await db.SaveChangesAsync();
        TempData["Success"] = "Запись удалена.";
        return RedirectToAction(nameof(Index));
    }
}
